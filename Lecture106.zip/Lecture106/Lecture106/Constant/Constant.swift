
import Foundation
struct Constant{
    static let textURL = "https://jsonplaceholder.typicode.com/todos"
    static let titleImageURL = "https://jsonplaceholder.typicode.com/photos"
}
