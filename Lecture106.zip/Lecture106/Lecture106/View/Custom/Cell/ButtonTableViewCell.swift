//
//  ButtonTableViewCell.swift
//  Lecture106
//
//  Created by Hongfei Zheng on 10/7/21.
//

import UIKit
import SDWebImage
import Kingfisher

class ButtonTableViewCell: UITableViewCell {
    var label = UILabel()
    var imageView1 = UIImageView()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupView()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupView()
    }
    
    func setupView(){
        label.translatesAutoresizingMaskIntoConstraints = false
        imageView1.translatesAutoresizingMaskIntoConstraints = false
        imageView1.backgroundColor = .blue
        label.text = "label"
        label.numberOfLines = 0
        addSubview(label)
        addSubview(imageView1)
        let ditionary = ["label":label,"image":imageView1]
        let imageH = NSLayoutConstraint.constraints(withVisualFormat: "H:|-10-[image]-10-[label]-10-|", options: [], metrics: nil, views: ditionary)
        let imageV = NSLayoutConstraint.constraints(withVisualFormat: "V:|-10-[image]-10-|", options: [], metrics: nil, views: ditionary)
        let height = NSLayoutConstraint.init(item: imageView1, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1.0, constant: 50)
        addConstraints(imageH)
        addConstraints(imageV)
        addConstraint(height)
        let labelH = NSLayoutConstraint.constraints(withVisualFormat: "H:|[image]-10-[label]-10-|", options: [], metrics: nil, views: ditionary)
        let labelV = NSLayoutConstraint.constraints(withVisualFormat: "V:|-10-[label]-10-|", options: [], metrics: nil, views: ditionary)
        let weight = NSLayoutConstraint.init(item: label, attribute: .width, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1.0, constant: 250)
        addConstraints(labelH)
        addConstraints(labelV)
        addConstraint(weight)
    }
    
    func setupCell(text:String, url: String){
        label.text = text
        // King fisher
//        if let imageUrl = URL(string: url){
//            self.imageView1.kf.setImage(with: imageUrl)
//        }
        // Extension
        self.imageView1.getImage(url)
        
        // SDwebImage
        //self.imageView1.sd_setImage(with: URL(string: url), placeholderImage: UIImage())
        
    }

}
