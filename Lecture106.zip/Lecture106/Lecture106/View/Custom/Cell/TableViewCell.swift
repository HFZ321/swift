//
//  TableViewCell.swift
//  Lecture106
//
//  Created by Hongfei Zheng on 10/6/21.
//

import UIKit

class TableViewCell: UITableViewCell {
    var label = UILabel.init()
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupCell()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupCell()
    }
//    override func layoutSubviews() {
//        super.layoutSubviews()
//
//        contentView.frame = contentView.frame.inset(by: UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10))
//    }
    func setupCell(){
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.backgroundColor = .orange
        label.textColor = .black
        addSubview(label)
        let ditionary = ["label":label]
        let H = NSLayoutConstraint.constraints(withVisualFormat: "H:|-5-[label]-5-|", options: [], metrics: nil, views: ditionary)
        let V = NSLayoutConstraint.constraints(withVisualFormat: "V:|-5-[label]-5-|", options: [], metrics: nil, views: ditionary)
        addConstraints(H)
        addConstraints(V)
    }
    func setupLabel(text:String){
        label.text = text
    }
    
    
   

}
