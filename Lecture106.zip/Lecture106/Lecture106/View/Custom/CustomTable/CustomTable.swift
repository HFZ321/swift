//
//  CustomTable.swift
//  Lecture106
//
//  Created by Hongfei Zheng on 10/6/21.
//

import UIKit
class CustomTable: UIView, UITableViewDelegate, UITableViewDataSource{
    var viewModel:ViewModel?
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel?.ToDos.count ?? 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as? TableViewCell
        cell?.setupLabel(text: viewModel?.ToDos[indexPath.row].title ?? "")
        return cell ?? TableViewCell()
    }

    let tableView = UITableView.init()
    override init(frame: CGRect) {
        super.init(frame: frame)
        //setView()
    }
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        //setView()
    }
    func setView(){
        addSubview(tableView)
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(TableViewCell.self, forCellReuseIdentifier: "cell")
        let ditionary = ["tableView":tableView]
        let H = NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[tableView]-0-|", options: [], metrics: nil, views: ditionary)
        let V = NSLayoutConstraint.constraints(withVisualFormat: "V:|-0-[tableView]-0-|", options: [], metrics: nil, views: ditionary)
        addConstraints(H)
        addConstraints(V)
    }
    
    
   
}
