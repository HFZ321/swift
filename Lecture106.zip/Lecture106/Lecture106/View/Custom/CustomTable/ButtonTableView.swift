//
//  ButtonTableView.swift
//  Lecture106
//
//  Created by Hongfei Zheng on 10/7/21.
//


import UIKit
class ButtonTableView: UIView, UITableViewDelegate, UITableViewDataSource{
    var model: TitleImage?
    var delegate: CellSelecte?
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //model?.titleImages.count ?? 0
        return 50
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as? ButtonTableViewCell
        let text = model?.titleImages[indexPath.row].title ?? ""
        let url = model?.titleImages[indexPath.row].url ?? ""
        cell?.setupCell(text:text, url: url)
        return cell ?? ButtonTableViewCell()
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        delegate?.cellSelect(row:indexPath.row)
    }
    
    let tableView = UITableView()
    override init(frame: CGRect) {
        super.init(frame: frame)
        
    }
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
    }
    func setupTable(){
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.delegate = self
        tableView.dataSource = self
        addSubview(tableView)
        tableView.register(ButtonTableViewCell.self, forCellReuseIdentifier: "cell")
        let ditionary = ["tableView":tableView]
        let H = NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[tableView]-0-|", options: [], metrics: nil, views: ditionary)
        let V = NSLayoutConstraint.constraints(withVisualFormat: "V:|-0-[tableView]-0-|", options: [], metrics: nil, views: ditionary)
        addConstraints(H)
        addConstraints(V)
    }
}

protocol CellSelecte{
    func cellSelect(row: Int)
}
