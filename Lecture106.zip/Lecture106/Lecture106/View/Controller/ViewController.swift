//
//  ViewController.swift
//  Lecture106
//
//  Created by Hongfei Zheng on 10/6/21.
//

import UIKit

class ViewController: UIViewController {
    let model = TitleImage()
    let tableView = ButtonTableView()
    override func viewDidLoad() {
        super.viewDidLoad()
        model.getTitleImage(completionHandler: {
            DispatchQueue.main.async {
                self.setupTable()
            }
        })
        
    }
    func setupTable(){
        
        tableView.setupTable()
        tableView.model = model
        tableView.delegate = self
        tableView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tableView)
        let ditionary = ["tableView":tableView]
        let H = NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[tableView]-0-|", options: [], metrics: nil, views: ditionary)
        let V = NSLayoutConstraint.constraints(withVisualFormat: "V:|-0-[tableView]-0-|", options: [], metrics: nil, views: ditionary)
        view.addConstraints(H)
        view.addConstraints(V)
    }


}

extension ViewController: CellSelecte{
    func cellSelect(row:Int) {
        let st = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "DetailViewController") as? DetailViewController
        if let v = vc{
            v.url = model.titleImages[row].url
            v.text = model.titleImages[row].title
            present(v, animated: true, completion: nil)
        }
       
    }
    
    
}


