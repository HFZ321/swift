//
//  DetailViewController.swift
//  Lecture106
//
//  Created by Hongfei Zheng on 10/7/21.
//

import UIKit

class DetailViewController: UIViewController {
    let detailImage = UIImageView()
    let detailLabel = UILabel()
    var url: String?
    var text: String?
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
        detailImage.getImage(url ?? "")
        detailLabel.text = text
    }
    func setupView(){
        detailImage.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(detailImage)
        detailLabel.text = "Label"
        detailLabel.translatesAutoresizingMaskIntoConstraints = false
        detailLabel.numberOfLines = 0
        view.addSubview(detailLabel)
        let ditionary = ["detailImage":detailImage, "detailLabel": detailLabel]
        let imageH = NSLayoutConstraint.constraints(withVisualFormat: "H:|-10-[detailImage]-10-|", options: [], metrics: nil, views: ditionary)
        let imageV = NSLayoutConstraint.constraints(withVisualFormat: "V:|-10-[detailImage]-10-[detailLabel]-|", options: [], metrics: nil, views: ditionary)
        let height = NSLayoutConstraint.init(item: detailImage, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1.0, constant: 400)
        view.addConstraints(imageH)
        view.addConstraints(imageV)
        view.addConstraint(height)
        let labelH = NSLayoutConstraint.constraints(withVisualFormat: "H:|-10-[detailLabel]-10-|", options: [], metrics: nil, views: ditionary)
        let labelV = NSLayoutConstraint.constraints(withVisualFormat: "V:|-[detailImage]-10-[detailLabel]-200-|", options: [], metrics: nil, views: ditionary)
        view.addConstraints(labelH)
        view.addConstraints(labelV)
    }
    

   
}
