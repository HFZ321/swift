//
//  TitleImage.swift
//  Lecture106
//
//  Created by Hongfei Zheng on 10/7/21.
//

import Foundation
class TitleImage{
    var titleImages = [ImageTitle]()
    func getTitleImage(completionHandler: (() -> ())?){
        if let url = URL.init(string: Constant.titleImageURL){
            ApiHandler.shared.getTitleImage(url: url) { titleImage in
                self.titleImages = titleImage ?? [ImageTitle]()
                completionHandler?()
            }
        }
    }
}
