//
//  ViewModel.swift
//  Lecture106
//
//  Created by Hongfei Zheng on 10/6/21.
//

import Foundation
class ViewModel{
    var ToDos = [ToDo]()
    func get(completionHandler: (() -> ())?){
        if let url = URL.init(string: Constant.textURL){
            ApiHandler.shared.get(url: url) { todos in
                self.ToDos = todos ?? [ToDo]()
                completionHandler?()
            }
        }
    }
    
}

