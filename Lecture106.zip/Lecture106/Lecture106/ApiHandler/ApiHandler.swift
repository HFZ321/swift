//
//  ApiHandler.swift
//  Lecture106
//
//  Created by Hongfei Zheng on 10/6/21.
//

import Foundation


class ApiHandler {
    
    //singleton
    static let shared = ApiHandler.init()
    typealias CompletionHandler = (([ToDo]?)->())?
    typealias ImageCH = (([ImageTitle]?)->())?
    //
    private init(){}
    
    func get(url:URL, completionHandler: CompletionHandler) {
        URLSession.shared.dataTask(with: url) { data, response, error in
            let model = try? JSONDecoder.init().decode([ToDo].self, from: data!)
            completionHandler?(model)
        }.resume()
    }
    func getTitleImage(url:URL, completionHandler: ImageCH) {
        URLSession.shared.dataTask(with: url) { data, response, error in
            let model = try? JSONDecoder.init().decode([ImageTitle].self, from: data!)
            completionHandler?(model)
        }.resume()
    }
    
    
}
