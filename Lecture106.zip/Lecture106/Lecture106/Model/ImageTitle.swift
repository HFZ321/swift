//
//  ImageTitle.swift
//  Lecture106
//
//  Created by Hongfei Zheng on 10/7/21.
//

import Foundation
struct ImageTitle:Decodable{
    var title: String
    var url: String
}

