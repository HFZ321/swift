//
//  ToDo.swift
//  Lecture106
//
//  Created by Hongfei Zheng on 10/6/21.
//

import Foundation
struct ToDo:Decodable{
    var title: String
    var completed: Bool
}
