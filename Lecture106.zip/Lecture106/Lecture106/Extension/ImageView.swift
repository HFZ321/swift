

import UIKit
extension UIImageView{
    func getImage(_ urlString: String){
        if let url = URL.init(string: urlString){
            DispatchQueue.global().async {
                if let data = try? Data(contentsOf: url){
                    
                    DispatchQueue.main.async {
                        self.image = UIImage(data: data)
                    }
                }
            
            }
        }
    }
}
